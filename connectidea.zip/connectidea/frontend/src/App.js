import React, { useState } from 'react';

function App() {
  const [messages, setMessages] = useState([]); // State to hold multiple messages

  const handleButtonClick = async () => {
    try {
      const response = await fetch('http://127.0.0.1:5000/api/data'); // Flask endpoint
      if (!response.ok) {
        throw new Error('Network response was not ok');
      }
      const data = await response.json();
      setMessages((prevMessages) => [...prevMessages, data.message]); // Append new message
    } catch (error) {
      console.error('There was a problem with the fetch operation:', error);
    }
  };

  return (
    <div>
      <button onClick={handleButtonClick}>Hi</button>
      <div>
        {messages.map((message, index) => (
          <p key={index}>Response from Flask: {message}</p> // Dynamically render messages
        ))}
      </div>
    </div>
  );
}

export default App;
