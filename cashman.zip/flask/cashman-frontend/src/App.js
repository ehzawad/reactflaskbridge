import React, { useState, useEffect } from 'react';

const ErrorState = ({ onRetry }) => (
  <div className="min-h-screen flex items-center justify-center bg-gray-50">
    <div className="max-w-md w-full p-8">
      <div className="text-center mb-8">
        <div className="bg-red-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
          <svg className="w-8 h-8 text-red-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
          </svg>
        </div>
        <h2 className="text-2xl font-bold text-gray-800 mb-2">Backend Connection Failed</h2>
        <div className="space-y-3">
          <p className="text-gray-600">We're unable to connect to the server. Please check:</p>
          <ul className="text-left text-sm text-gray-600 bg-white p-4 rounded-lg shadow-sm border border-gray-100">
            <li className="flex items-center mb-2">
              <span className="mr-2">•</span>
              <span>Is the Flask backend running?</span>
            </li>
            <li className="flex items-center mb-2">
              <span className="mr-2">•</span>
              <span>Is it running on port 5001?</span>
            </li>
            <li className="flex items-center">
              <span className="mr-2">•</span>
              <span>Did you run the bootstrap.sh script?</span>
            </li>
          </ul>
        </div>
      </div>
      <div className="flex justify-center">
        <button
          onClick={onRetry}
          className="bg-blue-500 hover:bg-blue-600 text-white px-6 py-3 rounded-lg font-medium shadow-sm transition-colors duration-200 flex items-center"
        >
          <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
          </svg>
          Retry Connection
        </button>
      </div>
    </div>
  </div>
);

const App = () => {
  const [incomes, setIncomes] = useState([]);
  const [expenses, setExpenses] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [formError, setFormError] = useState(null);
  const [newTransaction, setNewTransaction] = useState({
    description: '',
    amount: ''
  });

  const fetchData = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const [incomesResponse, expensesResponse] = await Promise.all([
        fetch('http://localhost:5001/incomes'),
        fetch('http://localhost:5001/expenses')
      ]);

      if (!incomesResponse.ok || !expensesResponse.ok) {
        throw new Error('Server error');
      }

      const incomesData = await incomesResponse.json();
      const expensesData = await expensesResponse.json();

      setIncomes(incomesData);
      setExpenses(expensesData);
      setError(null);
    } catch (err) {
      setError('Unable to connect to the server. Please make sure the backend is running.');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleSubmit = async (type) => {
    setFormError(null);

    // Form validation
    if (!newTransaction.description || !newTransaction.amount) {
      setFormError('Please fill in both description and amount');
      return;
    }

    // Amount validation
    if (isNaN(newTransaction.amount) || Number(newTransaction.amount) <= 0) {
      setFormError('Please enter a valid positive amount');
      return;
    }

    try {
      const endpoint = type === 'income' ? 'incomes' : 'expenses';
      
      const response = await fetch(`http://localhost:5001/${endpoint}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          description: newTransaction.description,
          amount: Number(newTransaction.amount)
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to add transaction');
      }

      setNewTransaction({ description: '', amount: '' });
      setFormError(null);
      fetchData();
    } catch (error) {
      setFormError('Failed to add transaction. Please check if the server is running.');
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-xl text-gray-600">Loading...</div>
      </div>
    );
  }

  if (error) {
    return <ErrorState onRetry={fetchData} />;
  }

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <h1 className="text-3xl font-bold mb-8 text-center">Cashman - Income/Expense Tracker</h1>
      
      <div className="mb-8 p-4 bg-white rounded-lg shadow">
        <h2 className="text-xl font-semibold mb-4">Add New Transaction</h2>
        {formError && (
          <div className="mb-4 p-3 bg-red-50 text-red-600 rounded border border-red-200">
            {formError}
          </div>
        )}
        <div className="space-y-4">
          <input
            type="text"
            value={newTransaction.description}
            onChange={(e) => setNewTransaction({...newTransaction, description: e.target.value})}
            placeholder="Description"
            className="w-full p-2 border rounded"
          />
          <input
            type="number"
            value={newTransaction.amount}
            onChange={(e) => setNewTransaction({...newTransaction, amount: e.target.value})}
            placeholder="Amount"
            className="w-full p-2 border rounded"
          />
          <div className="flex space-x-4">
            <button
              onClick={() => handleSubmit('income')}
              className="flex-1 bg-green-500 text-white p-2 rounded hover:bg-green-600"
            >
              Add Income
            </button>
            <button
              onClick={() => handleSubmit('expense')}
              className="flex-1 bg-red-500 text-white p-2 rounded hover:bg-red-600"
            >
              Add Expense
            </button>
          </div>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white p-4 rounded-lg shadow">
          <h2 className="text-xl font-semibold mb-4 text-green-600">Incomes</h2>
          <div className="space-y-2">
            {incomes.length === 0 ? (
              <p className="text-gray-500 text-center py-4">No incomes recorded yet</p>
            ) : (
              incomes.map((income, index) => (
                <div key={index} className="p-3 bg-green-50 rounded">
                  <div className="font-medium">{income.description}</div>
                  <div className="text-green-600">${income.amount}</div>
                </div>
              ))
            )}
          </div>
        </div>
        
        <div className="bg-white p-4 rounded-lg shadow">
          <h2 className="text-xl font-semibold mb-4 text-red-600">Expenses</h2>
          <div className="space-y-2">
            {expenses.length === 0 ? (
              <p className="text-gray-500 text-center py-4">No expenses recorded yet</p>
            ) : (
              expenses.map((expense, index) => (
                <div key={index} className="p-3 bg-red-50 rounded">
                  <div className="font-medium">{expense.description}</div>
                  <div className="text-red-600">${Math.abs(expense.amount)}</div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default App;
