# app.py
from flask import Flask, jsonify, request
from flask_cors import CORS  # Add this import
from model.expense import Expense, ExpenseSchema
from model.income import Income, IncomeSchema
from model.transaction_type import TransactionType

app = Flask(__name__)
CORS(app) 

transactions = [
    Income('Salary', 5000),
    Income('Dividends', 200),
    Expense('pizza', 50)
]


@app.route('/')
def home():
    return jsonify({
        "message": "Welcome to Cashman API",
        "endpoints": {
            "incomes": "/incomes",
            "expenses": "/expenses"
        }
    })

@app.route('/incomes')
def get_incomes():
    schema = IncomeSchema(many=True)
    incomes = schema.dump(
        filter(lambda t: t.type == TransactionType.INCOME, transactions)
    )
    return jsonify(incomes)

@app.route('/incomes', methods=['POST'])
def add_income():
    income = IncomeSchema().load(request.get_json())
    transactions.append(income)
    return "", 204

@app.route('/expenses')
def get_expenses():
    schema = ExpenseSchema(many=True)
    expenses = schema.dump(
        filter(lambda t: t.type == TransactionType.EXPENSE, transactions)
    )
    return jsonify(expenses)

@app.route('/expenses', methods=['POST'])
def add_expense():
    expense = ExpenseSchema().load(request.get_json())
    transactions.append(expense)
    return "", 204

if __name__ == "__main__":
    app.run(debug=True)
